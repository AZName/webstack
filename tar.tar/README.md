# webstack
个人导航标签页


来源于 https://github.com/WebStackPage/WebStackPage.github.io



由于浏览器的标签页太多了。突然间发现使用导航页也很不错。打造自己的导航页还是有必要的。
